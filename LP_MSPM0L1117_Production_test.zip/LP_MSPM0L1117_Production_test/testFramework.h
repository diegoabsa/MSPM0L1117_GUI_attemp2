/*
 * testFrameWork.h
 *
 *  Created on: Dec 21, 2012
 *      Author: a0406309
 */

#ifndef TESTFRAMEWORK_H_
#define TESTFRAMEWORK_H_

#include "testframeworkCommunication.h"
#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#define PASS 1
#define FAIL 0
#define FALSE 0


#define GPIO_LED1_IOMUX                                          (IOMUX_PINCM1)  //PA0
#define GPIO_LED1_PORT                                                  (GPIOA)
#define GPIO_LED1_PIN                                           (DL_GPIO_PIN_0)
#define GPIO_LED2_G_IOMUX                                       (IOMUX_PINCM44)  //PB18
#define GPIO_LED2_G_PORT                                                (GPIOB)
#define GPIO_LED2_G_PIN                                        (DL_GPIO_PIN_18)
#define GPIO_LED2_R_IOMUX                                       (IOMUX_PINCM43)  //PB17
#define GPIO_LED2_R_PORT                                                (GPIOB)
#define GPIO_LED2_R_PIN                                        (DL_GPIO_PIN_17)
#define GPIO_LED2_B_IOMUX                                       (IOMUX_PINCM33)  //PB16
#define GPIO_LED2_B_PORT                                                (GPIOB)
#define GPIO_LED2_B_PIN                                        (DL_GPIO_PIN_16)
#define GPIO_SW1_IOMUX                                          (IOMUX_PINCM40) //PA18
#define GPIO_SW1_PORT                                                   (GPIOA)
#define GPIO_SW1_PIN                                           (DL_GPIO_PIN_18)
#define GPIO_SW2_IOMUX                                          (IOMUX_PINCM10) //PA5
#define GPIO_SW2_PORT                                                   (GPIOA)
#define GPIO_SW2_PIN                                            (DL_GPIO_PIN_5)

#define POWER_STARTUP_DELAY                                                (16)

typedef struct {

	char (*setup)(void);
	char (*test)(void);
	unsigned int  timeoutms;
	unsigned char repeat;
	unsigned char continueOnFail;

} s_testcase;

extern const s_testcase testcases[];
extern const unsigned int numberOfTestcases;

typedef struct {
	unsigned char overallTestResult;
	unsigned char timeout;
	unsigned char repeat;
	unsigned char newStringReceived;
	char          txString[MAX_STR_LENGTH];
	char          rxString[MAX_STR_LENGTH];
} s_test;

extern s_test test;

char test_noSetup(void);
char test_waitForGuiToStart(void);
char test_testFramework(void);
void testFramework_Init(void);

#endif /* TESTFRAMEWORK_H_ */
