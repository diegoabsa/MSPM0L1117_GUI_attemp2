/*
 * test_current.h
 *
 *  Created on: Dec 15, 2014
 *      Author: a0221162
 */

#ifndef TEST_CURRENT_H_
#define TEST_CURRENT_H_

char test_setup_current(void);
char test_current_SLEEP0(void);

#endif /* TEST_CURRENT_H_ */
