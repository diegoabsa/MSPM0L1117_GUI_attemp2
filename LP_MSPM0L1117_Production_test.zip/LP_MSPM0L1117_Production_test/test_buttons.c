/*
 * test_buttons.c
 *
 *  Created on: Oct 24, 2014
 *      Author: a0221162
 */

#include "main.h"
#include "testFrameWork.h"
#include "stdio.h"
#include "string.h"
#include "test_buttons.h"

char test_setup_buttonLeftPress(void){

    // Initializes RED1, and RGB LED2
    DL_GPIO_initDigitalOutput(GPIO_LED2_G_IOMUX);
    DL_GPIO_enableOutput(GPIO_LED2_G_PORT, GPIO_LED2_G_PIN);
    DL_GPIO_clearPins(GPIO_LED2_G_PORT, GPIO_LED2_G_PIN);

    DL_GPIO_initDigitalOutput(GPIO_LED1_IOMUX);
    DL_GPIO_enableOutput(GPIO_LED1_PORT, GPIO_LED1_PIN);
    DL_GPIO_setPins(GPIO_LED1_PORT, GPIO_LED1_PIN);

    DL_GPIO_initDigitalOutput(GPIO_LED2_R_IOMUX);
    DL_GPIO_enableOutput(GPIO_LED2_R_PORT, GPIO_LED2_R_PIN);
    DL_GPIO_clearPins(GPIO_LED2_R_PORT, GPIO_LED2_R_PIN);

    DL_GPIO_initDigitalOutput(GPIO_LED2_B_IOMUX);
    DL_GPIO_enableOutput(GPIO_LED2_B_PORT, GPIO_LED2_B_PIN);
    DL_GPIO_clearPins(GPIO_LED2_B_PORT, GPIO_LED2_B_PIN);

    // Configures Switches in the board
    DL_GPIO_initDigitalInputFeatures(GPIO_SW1_IOMUX,
        DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_NONE,
        DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);
	//check if stuck low
	if(LEFT_SWITCH_PRESSED){
		//Result
		sprintf(test.txString,"@Left Button stuck low (FAIL)");
		return FAIL;
	}else{
		//Send instruction
		sprintf(test.txString,"!PRESS LEFT SWITCH(S1)");
		return PASS;
	}
}

char test_buttonLeftPress(void){
	//turn corresponding led on

    DL_GPIO_setPins(GPIO_LED2_G_PORT, GPIO_LED2_G_PIN);

	while (test.timeout==FALSE){
		if(LEFT_SWITCH_PRESSED){
			sprintf(test.txString,"@Left Button pressed (PASS)");
		    DL_GPIO_clearPins(GPIO_LED2_G_PORT, GPIO_LED2_G_PIN);
			return PASS;
		}
	}
	// timed out
	sprintf(test.txString,"@Left Button not pressed (FAIL)");
    DL_GPIO_clearPins(GPIO_LED2_G_PORT, GPIO_LED2_G_PIN);
	return FAIL;
}

char test_setup_buttonLeftRelease(void){

	//Send instruction
	sprintf(test.txString,"!Release LEFT switch (S1)");
	return PASS;
}

char test_buttonLeftRelease(void){
	//turn corresponding led on
    DL_GPIO_setPins(GPIO_LED2_G_PORT, GPIO_LED2_G_PIN);

	while (test.timeout==FALSE){
		if(!LEFT_SWITCH_PRESSED){
			sprintf(test.txString,"@Left Button released (PASS)");
            DL_GPIO_clearPins(GPIO_LED2_G_PORT, GPIO_LED2_G_PIN);
			return PASS;
		}
	}
	// timed out
	sprintf(test.txString,"@Left Button not released (FAIL)");
    DL_GPIO_clearPins(GPIO_LED2_G_PORT, GPIO_LED2_G_PIN);
	return FAIL;
}


char test_setup_buttonRightPress(void){

//    DL_GPIO_initDigitalOutput(GPIO_LED1_IOMUX);
//    DL_GPIO_enableOutput(GPIO_LED1_PORT, GPIO_LED1_PIN);
    DL_GPIO_setPins(GPIO_LED1_PORT, GPIO_LED1_PIN);

    DL_GPIO_initDigitalInputFeatures(GPIO_SW2_IOMUX,
        DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_UP,
        DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);
	//check if stuck low
	if(RIGHT_SWITCH_PRESSED){
		//Result
		sprintf(test.txString,"@Right Button stuck low (FAIL)");
		return FAIL;
	}else{
		//Send instruction
		sprintf(test.txString,"!PRESS RIGHT SWITCH(S2)");
		return PASS;
	}
}

char test_buttonRightPress(void){
	//turn corresponding led on
    DL_GPIO_clearPins(GPIO_LED1_PORT, GPIO_LED1_PIN);

	while (test.timeout==FALSE){
		if(RIGHT_SWITCH_PRESSED){
			sprintf(test.txString,"@Right Button pressed (PASS)");
			DL_GPIO_setPins(GPIO_LED1_PORT, GPIO_LED1_PIN);
			return PASS;
		}
	}
	// timed out
	sprintf(test.txString,"@Right Button not pressed (FAIL)");
	DL_GPIO_setPins(GPIO_LED1_PORT, GPIO_LED1_PIN);
	return FAIL;
}

char test_setup_buttonRightRelease(void){

	//Send instruction
	sprintf(test.txString,"!Release RIGHT switch (S2)");
	return PASS;
}

char test_buttonRightRelease(void){
	//turn corresponding led on
    DL_GPIO_clearPins(GPIO_LED1_PORT, GPIO_LED1_PIN);

	while (test.timeout==FALSE){
		if(!RIGHT_SWITCH_PRESSED){
			sprintf(test.txString,"@Right Button released (PASS)");
			DL_GPIO_setPins(GPIO_LED1_PORT, GPIO_LED1_PIN);
			return PASS;
		}
	}
	// timed out
	sprintf(test.txString,"@Right Button not released (FAIL)");
	DL_GPIO_setPins(GPIO_LED1_PORT, GPIO_LED1_PIN);
	return FAIL;
}
