/*
 * test_dieRecord.h
 *
 *  Created on: Oct 24, 2014
 *      Author: a0221162
 */

#ifndef TEST_DIERECORD_H_
#define TEST_DIERECORD_H_

char test_dieRecord(void);

#endif /* TEST_DIERECORD_H_ */
