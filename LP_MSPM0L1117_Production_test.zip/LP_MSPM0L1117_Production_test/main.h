
#ifndef MAIN_H_
#define MAIN_H_

#define CONFIG_MSPM0L111X
//#include <ti/devices/msp/msp.h>
//#include <ti/devices/msp/m0p/mspm0l1117.h>
#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#define MAX_STR_LENGTH 64

#define FWVERSION  "1.00"


// Choose MCLK frequency


#define FALSE 0
#define TRUE  1




void boardInit(void);

#endif /* MAIN_H_ */
