/*
 * test_current.c
 *
 *  Created on: Dec 15, 2014
 *      Author: a0221162
 */

#include "main.h"
#include "testFrameWork.h"
#include "stdio.h"
#include "string.h"
#include "stdlib.h"
#include "test_current.h"

char test_setup_current(void){

    DL_GPIO_reset(GPIOA);
//    DL_GPIO_reset(GPIOB); // Keep B for UART

	//Request Current measurement data from GUI
	sprintf(test.txString,"#MEAS CURRENT");

	return PASS;
}

char test_current_SLEEP0(void){
	char partOfString[MAX_STR_LENGTH];
	char * pCharPart;
	int intValue;
	char result = FAIL;

	while (test.newStringReceived == FALSE){

	    /* Set power policy to SLEEP0 first */
	    DL_SYSCTL_setPowerPolicyRUN0SLEEP0();
		//__delay_cycles(100000); // give PC some time...
	}

	strcpy(partOfString,test.rxString);
	test.newStringReceived = FALSE;

	// parse answer from PC
	pCharPart = strtok(partOfString," ");
	if(strcmp(pCharPart,"#MEAS")==0){
		pCharPart = strtok(NULL, " ");
		if(strcmp(pCharPart,"RESULT")==0){
			if (pCharPart !=NULL){
				pCharPart = strtok(NULL, " ");
				intValue = atoi(pCharPart);
				result = 3; // -> value received
			}
		}
	}

	// was result received?
	if (result == 3){ 	//Value received
		#define MAX_ALLOWED_CURRENT 8000
		if(intValue<MAX_ALLOWED_CURRENT){
			result= PASS;
			sprintf(test.txString,"@SL0_LDO current %duA, Limit %duA (PASS)",intValue,MAX_ALLOWED_CURRENT);
		}else{
			result = FAIL;
			sprintf(test.txString,"@SL0_LDO current %duA, Limit %duA (FAIL)",intValue,MAX_ALLOWED_CURRENT);
		}
	}else{
		result = FAIL;
		sprintf(test.txString,"@Sleep current Error in Return String (FAIL)");
	}
	return result;
}
