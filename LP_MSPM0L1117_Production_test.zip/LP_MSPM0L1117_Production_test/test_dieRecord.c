/*
 * test_dieRecord.c
 *
 */

//#include "main.h"
#include "testFrameWork.h"
#include "stdio.h"
#include "string.h"

char test_dieRecord(void){
    // Read Device
//
#ifndef FPGA_TEST
    unsigned int  TraceID  = *((unsigned int *) (0x41c40000));
#else
    *((unsigned int *) (0x20003000)) = 0x5555;
    unsigned int  TraceID  = *((unsigned int *) (0x20003000));
#endif
    sprintf(test.txString,"@TRACEID : %u ",TraceID);
    return PASS;
}
