
/*
CCS Version:  Version: 12.8.1.00005
Compiler version : TI Clang v3.2.2.LTS
SDK version: 2.02.00.06_internal
10/01/2024
 */
#include <main.h>
#include "testFramework.h"
// Prototypes
void boardInit(void);

int main(void)
{

    // workaround for first power up need wait some for clock stable
    delay_cycles(900000);
    delay_cycles(900000);
    delay_cycles(900000);
    delay_cycles(900000);
    int i=0, k;
    SYSCFG_DL_init();

    unsigned char numTests = numberOfTestcases;
    char result;

    testFramework_Init();

#define WAITTIMEAFTERTX 400000
    for(i = 0; i < numTests; /***/ ){

        // Setup Function
        //timeout
        if(testcases[i].timeoutms >= 1000){
            sprintf(test.txString,"#SET TIMEOUT 0%ds",(unsigned int)((testcases[i].timeoutms)/1000));
            sendText(); // fail log or instruction
            for (k = WAITTIMEAFTERTX; k > 0; k--);        // Delay
        }

        result = testcases[i].setup();
        sendText(); // fail log or instruction
        for (k = WAITTIMEAFTERTX; k > 0; k--);        // Delay

        // Actual Test only if setup succeeded

        if(result == PASS){
            result = testcases[i].test();
            sendText(); // test result
            for (k = WAITTIMEAFTERTX; k > 0; k--);        // Delay
        }

        // check test result
        if(result == PASS){
            i++;
            test.repeat = 0;
        }else{ /*fail*/
            if(testcases[i].repeat > test.repeat){
                test.repeat++;
                // one more time!
            }else if (testcases[i].continueOnFail){
                i++;
                test.repeat = 0;
            }else{
                test.overallTestResult = FAIL;
                test.repeat = 0;
                break;
            }
        }
        sprintf(test.txString,"!"); // Clear operator window
        sendText();
        for (k = WAITTIMEAFTERTX; k > 0; k--);  // give PC some time...
    }

    // sum up!
    if(test.overallTestResult == PASS){
        for (k = WAITTIMEAFTERTX; k > 0; k--);  // give PC some time...
        sprintf(test.txString,"#END(PASS)");
        sendText();
        for (k = WAITTIMEAFTERTX; k > 0; k--);  // give PC some time...
        sprintf(test.txString,"!Target Test PASS");
        sendText();
        for (k = WAITTIMEAFTERTX; k > 0; k--);  // give PC some time...
    }else{
        for (k = WAITTIMEAFTERTX; k > 0; k--);  // give PC some time...
        sprintf(test.txString,"#END(FAIL)");
        sendText();
        for (k = WAITTIMEAFTERTX; k > 0; k--);  // give PC some time...
        sprintf(test.txString,"!Target Test FAIL - This board is bad!");
        sendText();
        for (k = WAITTIMEAFTERTX; k > 0; k--);  // give PC some time...
    }

    while(1);
}


